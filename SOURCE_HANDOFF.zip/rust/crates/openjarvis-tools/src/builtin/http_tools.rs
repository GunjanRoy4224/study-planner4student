//! HTTP request tool.

use crate::traits::BaseTool;
use openjarvis_core::{OpenJarvisError, ToolResult, ToolSpec};
use once_cell::sync::Lazy;
use serde_json::Value;
use std::collections::HashMap;

static SPEC: Lazy<ToolSpec> = Lazy::new(|| ToolSpec {
    name: "http_request".into(),
    description: "Make an HTTP request".into(),
    parameters: serde_json::json!({
        "type": "object",
        "properties": {
            "url": { "type": "string", "description": "URL to request" },
            "method": { "type": "string", "description": "HTTP method (GET, POST, etc.)" },
            "body": { "type": "string", "description": "Request body (optional)" },
            "headers": { "type": "object", "description": "HTTP headers (optional)" }
        },
        "required": ["url"]
    }),
    category: "network".into(),
    cost_estimate: 0.0,
    latency_estimate: 0.0,
    requires_confirmation: false,
    timeout_seconds: 30.0,
    required_capabilities: vec!["network:fetch".into()],
    metadata: HashMap::new(),
});

pub struct HttpRequestTool;

impl BaseTool for HttpRequestTool {
    fn tool_id(&self) -> &str {
        "http_request"
    }
    fn spec(&self) -> &ToolSpec {
        &SPEC
    }
    fn execute(&self, params: &Value) -> Result<ToolResult, OpenJarvisError> {
        let mut current_url = match params["url"].as_str() {
            Some(u) => u.to_string(),
            None => return Ok(ToolResult::failure("http_request", "Missing URL")),
        };
        let mut current_method = params["method"].as_str().unwrap_or("GET").to_uppercase();
        let mut current_body = params["body"].as_str().map(|s| s.to_string());
        let initial_url_parsed = reqwest::Url::parse(&current_url).map_err(|e| {
            OpenJarvisError::Io(std::io::Error::other(format!("Invalid URL: {e}")))
        })?;
        let initial_origin = initial_url_parsed.origin();

        let headers_opt = params.get("headers").and_then(|h| h.as_object());
        let mut current_headers: Vec<(String, String)> = Vec::new();
        if let Some(headers) = headers_opt {
            for (k, v) in headers {
                if let Some(val) = v.as_str() {
                    current_headers.push((k.to_string(), val.to_string()));
                }
            }
        }

        let max_redirects = 5;
        let mut redirect_count = 0;

        loop {
            let (canonical_host, socket_addr) = match openjarvis_security::ssrf::validate_and_resolve(&current_url) {
                Ok(pair) => pair,
                Err(e) => return Ok(ToolResult::failure("http_request", format!("SSRF protection blocked request: {e}"))),
            };

            let client = reqwest::blocking::Client::builder()
                .resolve(&canonical_host, socket_addr)
                .redirect(reqwest::redirect::Policy::none())
                .timeout(std::time::Duration::from_secs(30))
                .build()
                .map_err(|e| {
                    OpenJarvisError::Io(std::io::Error::other(e.to_string()))
                })?;

            let mut request = match current_method.as_str() {
                "POST" => client.post(&current_url),
                "PUT" => client.put(&current_url),
                "DELETE" => client.delete(&current_url),
                "PATCH" => client.patch(&current_url),
                "HEAD" => client.head(&current_url),
                _ => client.get(&current_url),
            };

            if let Some(ref body) = current_body {
                request = request.body(body.clone());
            }

            for (k, v) in &current_headers {
                request = request.header(k.as_str(), v.as_str());
            }

            match request.send() {
                Ok(resp) => {
                    let status = resp.status();
                    if status.is_redirection() {
                        redirect_count += 1;
                        if redirect_count > max_redirects {
                            return Ok(ToolResult::failure("http_request", "SSRF protection blocked redirect: Exceeded maximum redirects"));
                        }

                        let location = match resp.headers().get(reqwest::header::LOCATION) {
                            Some(loc) => match loc.to_str() {
                                Ok(s) => s,
                                Err(_) => return Ok(ToolResult::failure("http_request", "Invalid Location header in redirect")),
                            },
                            None => return Ok(ToolResult::failure("http_request", "Redirect missing Location header")),
                        };

                        let base = reqwest::Url::parse(&current_url).map_err(|e| {
                            OpenJarvisError::Io(std::io::Error::other(format!("Invalid URL: {e}")))
                        })?;

                        let next_url = match base.join(location) {
                            Ok(u) => u.to_string(),
                            Err(e) => return Ok(ToolResult::failure("http_request", format!("Invalid redirect destination: {e}"))),
                        };

                        if let Ok(next_parsed) = reqwest::Url::parse(&next_url) {
                            if next_parsed.origin() != initial_origin {
                                current_headers.retain(|(k, _)| {
                                    let lower = k.to_lowercase();
                                    !lower.contains("auth")
                                        && !lower.contains("cookie")
                                        && !lower.contains("token")
                                        && !lower.contains("secret")
                                        && !lower.contains("key")
                                });
                            }
                        }

                        if status == reqwest::StatusCode::SEE_OTHER
                            || status == reqwest::StatusCode::MOVED_PERMANENTLY
                            || status == reqwest::StatusCode::FOUND
                        {
                            current_method = "GET".to_string();
                            current_body = None;
                        }

                        current_url = next_url;
                        continue;
                    }

                    let status_code = status.as_u16();
                    let body = resp.text().unwrap_or_default();
                    let truncated = if body.len() > 10000 {
                        format!("{}...(truncated)", &body[..10000])
                    } else {
                        body
                    };
                    let content = format!("Status: {status_code}\n{truncated}");
                    if status_code < 400 {
                        return Ok(ToolResult::success("http_request", content));
                    } else {
                        return Ok(ToolResult::failure("http_request", content));
                    }
                }
                Err(e) => {
                    return Ok(ToolResult::failure(
                        "http_request",
                        format!("Request failed: {e}"),
                    ));
                }
            }
        }
    }
}
