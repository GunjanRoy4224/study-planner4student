//! SSRF protection — block requests to private IPs and cloud metadata endpoints.

use once_cell::sync::Lazy;
use std::collections::HashSet;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, ToSocketAddrs};

static BLOCKED_HOSTS: Lazy<HashSet<&'static str>> = Lazy::new(|| {
    HashSet::from([
        "169.254.169.254",
        "metadata.google.internal",
        "metadata.google.com",
        "100.100.100.200",
    ])
});

/// Normalize an IPv6 address to its embedded IPv4 if it is an IPv4-mapped
/// (`::ffff:a.b.c.d`) or IPv4-compatible (`::a.b.c.d`, deprecated) form.
/// Returns `None` for `::` and `::1` (these are checked as IPv6 directly).
fn embedded_ipv4(v6: &Ipv6Addr) -> Option<Ipv4Addr> {
    if let Some(v4) = v6.to_ipv4_mapped() {
        return Some(v4);
    }
    let seg = v6.segments();
    // NAT64 well-known prefix 64:ff9b::/96 (RFC 6052): IPv4 in the last 32 bits.
    if seg[0] == 0x0064
        && seg[1] == 0xff9b
        && seg[2] == 0
        && seg[3] == 0
        && seg[4] == 0
        && seg[5] == 0
    {
        return Some(Ipv4Addr::new(
            (seg[6] >> 8) as u8,
            (seg[6] & 0xff) as u8,
            (seg[7] >> 8) as u8,
            (seg[7] & 0xff) as u8,
        ));
    }
    // 6to4 2002::/16 (RFC 3056): IPv4 in bits 16-47.
    if seg[0] == 0x2002 {
        return Some(Ipv4Addr::new(
            (seg[1] >> 8) as u8,
            (seg[1] & 0xff) as u8,
            (seg[2] >> 8) as u8,
            (seg[2] & 0xff) as u8,
        ));
    }
    // IPv4-compatible (::a.b.c.d) — RFC 4291 deprecated but still parseable.
    // Excludes `::` and `::1` which must be classified as IPv6.
    let segments = v6.segments();
    if segments[0] == 0
        && segments[1] == 0
        && segments[2] == 0
        && segments[3] == 0
        && segments[4] == 0
        && segments[5] == 0
        && !v6.is_unspecified()
        && !v6.is_loopback()
    {
        let octets: [u8; 4] = [
            (segments[6] >> 8) as u8,
            (segments[6] & 0xff) as u8,
            (segments[7] >> 8) as u8,
            (segments[7] & 0xff) as u8,
        ];
        return Some(Ipv4Addr::from(octets));
    }
    None
}

/// Check if an IP address is private/reserved.
pub fn is_private_ip(ip: &IpAddr) -> bool {
    match ip {
        IpAddr::V4(v4) => {
            v4.is_loopback()
                || v4.is_private()
                || v4.is_link_local()
                || is_in_cidr_v4(v4, Ipv4Addr::new(169, 254, 0, 0), 16)
                || *v4 == Ipv4Addr::UNSPECIFIED
                || v4.is_broadcast()
                || v4.is_multicast()
                // 0.0.0.0/8 — current network, routes to localhost on Linux
                || v4.octets()[0] == 0
                // 100.64.0.0/10 — shared address space (CGNAT). Alibaba's
                // metadata service (100.100.100.200) lives here.
                || is_in_cidr_v4(v4, Ipv4Addr::new(100, 64, 0, 0), 10)
                // 192.0.0.0/24 — IETF protocol assignments
                || (is_in_cidr_v4(v4, Ipv4Addr::new(192, 0, 0, 0), 24)
                    && v4.octets() != [192, 0, 0, 9]
                    && v4.octets() != [192, 0, 0, 10])
                // 198.18.0.0/15 — benchmarking
                || is_in_cidr_v4(v4, Ipv4Addr::new(198, 18, 0, 0), 15)
                // 240.0.0.0/4 — reserved (includes 255.255.255.255)
                || is_in_cidr_v4(v4, Ipv4Addr::new(240, 0, 0, 0), 4)
        }
        IpAddr::V6(v6) => {
            // IPv4-mapped (`::ffff:a.b.c.d`) and IPv4-compatible (`::a.b.c.d`)
            // addresses must be classified by their embedded IPv4. Without
            // this, the IPv6 checks below never match RFC1918 / loopback /
            // link-local ranges and the address is treated as public.
            if let Some(v4) = embedded_ipv4(v6) {
                return is_private_ip(&IpAddr::V4(v4));
            }
            v6.is_loopback()
                || v6.is_unspecified()
                || v6.is_multicast()
                || is_ula_v6(v6)
                || is_link_local_v6(v6)
                // RFC 8215 local-use translation prefix is not global space.
                || (v6.segments()[0] == 0x64
                    && v6.segments()[1] == 0xff9b
                    && v6.segments()[2] == 1)
        }
    }
}

fn is_in_cidr_v4(addr: &Ipv4Addr, network: Ipv4Addr, prefix_len: u32) -> bool {
    let mask = if prefix_len == 0 {
        0u32
    } else {
        !0u32 << (32 - prefix_len)
    };
    (u32::from(*addr) & mask) == (u32::from(network) & mask)
}

fn is_ula_v6(addr: &Ipv6Addr) -> bool {
    let segments = addr.segments();
    (segments[0] & 0xfe00) == 0xfc00
}

fn is_link_local_v6(addr: &Ipv6Addr) -> bool {
    let segments = addr.segments();
    (segments[0] & 0xffc0) == 0xfe80
}

/// Validate a URL against SSRF and return the canonical host and the validated SocketAddr.
/// This SocketAddr can be passed to reqwest's ClientBuilder::resolve() to pin the connection
/// to the validated IP, preventing DNS rebinding attacks while preserving SNI and TLS cert validation.
pub fn validate_and_resolve(url_str: &str) -> Result<(String, std::net::SocketAddr), String> {
    let parsed = match url::Url::parse(url_str) {
        Ok(u) => u,
        Err(_) => return Err("Invalid URL".into()),
    };

    let host = match parsed.host() {
        Some(h) => h,
        None => return Err("No hostname in URL".into()),
    };

    let port = parsed.port().unwrap_or(match parsed.scheme() {
        "https" => 443,
        _ => 80,
    });

    let literal_ip: Option<IpAddr> = match &host {
        url::Host::Ipv4(v4) => Some(IpAddr::V4(*v4)),
        url::Host::Ipv6(v6) => Some(
            embedded_ipv4(v6).map(IpAddr::V4).unwrap_or(IpAddr::V6(*v6)),
        ),
        url::Host::Domain(_) => None,
    };

    let canonical_host: String = match (&literal_ip, &host) {
        (Some(IpAddr::V4(v4)), _) => v4.to_string(),
        (Some(IpAddr::V6(v6)), _) => v6.to_string(),
        (None, url::Host::Domain(d)) => d.to_string(),
        _ => unreachable!(),
    };

    if BLOCKED_HOSTS.contains(canonical_host.as_str()) {
        return Err(format!(
            "Blocked host: {canonical_host} (cloud metadata endpoint)"
        ));
    }

    if let Some(ip) = literal_ip {
        if is_private_ip(&ip) {
            return Err(format!("URL resolves to private IP: {ip}"));
        }
        return Ok((canonical_host, std::net::SocketAddr::new(ip, port)));
    }

    let addr_str = format!("{canonical_host}:{port}");
    match addr_str.to_socket_addrs() {
        Ok(addrs) => {
            let mut first_safe: Option<std::net::SocketAddr> = None;
            for addr in addrs {
                if is_private_ip(&addr.ip()) {
                    return Err(format!("URL resolves to private IP: {}", addr.ip()));
                }
                if first_safe.is_none() {
                    first_safe = Some(addr);
                }
            }
            match first_safe {
                Some(sa) => Ok((canonical_host, sa)),
                None => Err(format!(
                    "Could not resolve host (blocked, fail-closed): {canonical_host}"
                )),
            }
        }
        Err(_) => Err(format!(
            "Could not resolve host (blocked, fail-closed): {canonical_host}"
        )),
    }
}

/// Check a URL for SSRF vulnerabilities.
/// Returns an error message or None if safe.
pub fn check_ssrf(url_str: &str) -> Option<String> {
    match validate_and_resolve(url_str) {
        Ok(_) => None,
        Err(err) => Some(err),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_private_ip_detection() {
        assert!(is_private_ip(&IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1))));
        assert!(is_private_ip(&IpAddr::V4(Ipv4Addr::new(192, 168, 1, 1))));
        assert!(is_private_ip(&IpAddr::V4(Ipv4Addr::new(172, 16, 0, 1))));
        assert!(is_private_ip(&IpAddr::V4(Ipv4Addr::LOCALHOST)));
    }

    #[test]
    fn test_cgnat_and_reserved_ranges_are_private() {
        for (a, b, c, d) in [
            (100, 100, 100, 200),
            (100, 64, 0, 1),
            (100, 127, 255, 255),
            (198, 18, 0, 1),
            (192, 0, 0, 192),
            (240, 0, 0, 1),
        ] {
            assert!(is_private_ip(&IpAddr::V4(Ipv4Addr::new(a, b, c, d))));
        }
        assert!(!is_private_ip(&IpAddr::V4(Ipv4Addr::new(100, 128, 0, 1))));
        assert!(!is_private_ip(&IpAddr::V4(Ipv4Addr::new(198, 20, 0, 1))));
        // Globally reachable PCP and TURN anycast exceptions in 192.0.0/24.
        assert!(!is_private_ip(&IpAddr::V4(Ipv4Addr::new(192, 0, 0, 9))));
        assert!(!is_private_ip(&IpAddr::V4(Ipv4Addr::new(192, 0, 0, 10))));
    }

    #[test]
    fn test_nat64_and_6to4_use_embedded_ipv4() {
        let nat64_loopback: Ipv6Addr = "64:ff9b::7f00:1".parse().unwrap();
        let nat64_public: Ipv6Addr = "64:ff9b::808:808".parse().unwrap();
        let sixtofour_loopback: Ipv6Addr = "2002:7f00:1::1".parse().unwrap();
        let sixtofour_public: Ipv6Addr = "2002:808:808::1".parse().unwrap();
        assert!(is_private_ip(&IpAddr::V6(nat64_loopback)));
        assert!(!is_private_ip(&IpAddr::V6(nat64_public)));
        assert!(is_private_ip(&IpAddr::V6(sixtofour_loopback)));
        assert!(!is_private_ip(&IpAddr::V6(sixtofour_public)));
    }

    #[test]
    fn test_local_use_nat64_prefix_is_blocked() {
        for address in [
            "64:ff9b:1::",
            "64:ff9b:1::7f00:1",
            "64:ff9b:1:ffff:ffff:ffff:ffff:ffff",
        ] {
            assert!(is_private_ip(&address.parse().unwrap()));
        }
        assert!(!is_private_ip(&"64:ff9b:2::1".parse().unwrap()));
    }

    #[test]
    fn test_public_ip_allowed() {
        assert!(!is_private_ip(&IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8))));
        assert!(!is_private_ip(&IpAddr::V4(Ipv4Addr::new(1, 1, 1, 1))));
    }

    #[test]
    fn test_blocked_metadata_host() {
        let result = check_ssrf("http://169.254.169.254/latest/meta-data/");
        assert!(result.is_some());
        assert!(result.unwrap().contains("Blocked host"));
    }

    #[test]
    fn test_invalid_url() {
        let result = check_ssrf("not-a-url");
        assert!(result.is_some());
    }

    #[test]
    fn test_ipv4_mapped_ipv6_loopback_is_private() {
        // ::ffff:127.0.0.1
        let mapped: Ipv6Addr = "::ffff:127.0.0.1".parse().unwrap();
        assert!(is_private_ip(&IpAddr::V6(mapped)));
    }

    #[test]
    fn test_ipv4_mapped_ipv6_rfc1918_is_private() {
        for s in ["::ffff:10.0.0.1", "::ffff:172.16.0.1", "::ffff:192.168.1.1"] {
            let v6: Ipv6Addr = s.parse().unwrap();
            assert!(is_private_ip(&IpAddr::V6(v6)), "{s} should be private");
        }
    }

    #[test]
    fn test_ipv4_mapped_ipv6_link_local_is_private() {
        let v6: Ipv6Addr = "::ffff:169.254.0.1".parse().unwrap();
        assert!(is_private_ip(&IpAddr::V6(v6)));
    }

    #[test]
    fn test_ipv4_mapped_public_ipv6_allowed() {
        // ::ffff:8.8.8.8 — public IPv4 wrapped as IPv6 must NOT be flagged.
        let v6: Ipv6Addr = "::ffff:8.8.8.8".parse().unwrap();
        assert!(!is_private_ip(&IpAddr::V6(v6)));
    }

    #[test]
    fn test_ipv6_unspecified_is_private() {
        assert!(is_private_ip(&IpAddr::V6(Ipv6Addr::UNSPECIFIED)));
    }

    #[test]
    fn test_check_ssrf_blocks_ipv4_mapped_loopback_url() {
        let result = check_ssrf("http://[::ffff:127.0.0.1]:6666");
        assert!(result.is_some(), "::ffff:127.0.0.1 must be blocked");
        assert!(result.unwrap().contains("private IP"));
    }

    #[test]
    fn test_check_ssrf_blocks_ipv4_mapped_rfc1918_url() {
        for url in [
            "http://[::ffff:10.0.0.1]/",
            "http://[::ffff:192.168.1.1]/",
            "http://[::ffff:172.16.0.1]/",
        ] {
            let result = check_ssrf(url);
            assert!(result.is_some(), "{url} must be blocked");
        }
    }

    #[test]
    fn test_check_ssrf_blocks_ipv4_mapped_metadata_url() {
        // ::ffff:169.254.169.254 — IPv4-mapped form of AWS/GCP metadata IP.
        let result = check_ssrf("http://[::ffff:169.254.169.254]/latest/meta-data/");
        assert!(result.is_some());
    }

    #[test]
    fn test_check_ssrf_blocks_ipv6_loopback_literal() {
        // Bracketed IPv6 literal must be checked even though `host:port`
        // string parsing of the unbracketed form is ambiguous.
        let result = check_ssrf("http://[::1]:80/");
        assert!(result.is_some());
    }

    #[test]
    fn test_check_ssrf_allows_ipv4_mapped_public() {
        let result = check_ssrf("http://[::ffff:8.8.8.8]/");
        assert!(
            result.is_none(),
            "public IP wrapped as IPv6 must be allowed"
        );
    }

    #[test]
    fn test_check_ssrf_blocks_ipv4_mapped_alibaba_metadata() {
        // ::ffff:100.100.100.200 — Alibaba metadata; not in any private CIDR,
        // so must be caught by `BLOCKED_HOSTS` lookup on the normalized IPv4.
        let result = check_ssrf("http://[::ffff:100.100.100.200]/");
        assert!(
            result.is_some(),
            "Alibaba metadata via mapped form must be blocked"
        );
        assert!(result.unwrap().contains("Blocked host"));
    }

    #[test]
    fn test_check_ssrf_blocks_ipv4_compatible_loopback() {
        // ::127.0.0.1 — deprecated IPv4-compatible form; defense-in-depth.
        let result = check_ssrf("http://[::127.0.0.1]/");
        assert!(result.is_some(), "::127.0.0.1 must be blocked");
    }

    #[test]
    fn test_check_ssrf_blocks_zero_dot_zero() {
        // 0.0.0.0 — connects to localhost on Linux.
        let result = check_ssrf("http://0.0.0.0/");
        assert!(result.is_some());
    }

    #[test]
    fn test_is_private_ip_unspecified_v4_v6() {
        assert!(is_private_ip(&IpAddr::V4(Ipv4Addr::UNSPECIFIED)));
        assert!(is_private_ip(&IpAddr::V6(Ipv6Addr::UNSPECIFIED)));
    }

    #[test]
    fn test_is_private_ip_blocks_multicast_and_broadcast() {
        assert!(is_private_ip(&IpAddr::V4(Ipv4Addr::new(239, 0, 0, 1))));
        assert!(is_private_ip(&IpAddr::V4(Ipv4Addr::BROADCAST)));
    }

    #[test]
    fn test_embedded_ipv4_compatibility() {
        // IPv4-compatible: ::a.b.c.d
        let v6: Ipv6Addr = "::127.0.0.1".parse().unwrap();
        assert_eq!(embedded_ipv4(&v6), Some(Ipv4Addr::new(127, 0, 0, 1)));
        // ::1 must NOT be treated as IPv4-compatible
        assert_eq!(embedded_ipv4(&Ipv6Addr::LOCALHOST), None);
        // :: must NOT be treated as IPv4-compatible
        assert_eq!(embedded_ipv4(&Ipv6Addr::UNSPECIFIED), None);
        // Mapped form
        let v6: Ipv6Addr = "::ffff:127.0.0.1".parse().unwrap();
        assert_eq!(embedded_ipv4(&v6), Some(Ipv4Addr::new(127, 0, 0, 1)));
    }
}
